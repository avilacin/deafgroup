import os
from datetime import datetime, timedelta
from flask import render_template, redirect, url_for, flash, request, jsonify, abort
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy import func, desc
from urllib.parse import urlparse

from app import app, db
from models import User, Dish, Category, Order, OrderItem, Staff, Inventory
from forms import LoginForm, DishForm, StaffForm, OrderForm, OrderItemForm, CategoryForm, DateRangeForm

# Create initial admin user if none exists
def create_admin():
    if User.query.count() == 0:
        admin = User(username='admin', email='admin@filipinorestaurant.com', is_admin=True)
        admin.set_password('admin123')
        
        # Create initial categories
        categories = [
            Category(name='Main Dishes', description='Delicious Filipino main courses'),
            Category(name='Desserts', description='Sweet Filipino desserts'),
            Category(name='Appetizers', description='Filipino appetizers and snacks'),
            Category(name='Beverages', description='Filipino drinks and refreshments')
        ]
        
        db.session.add(admin)
        db.session.add_all(categories)
        db.session.commit()

# Register create_admin with app
with app.app_context():
    create_admin()

# Auth routes
@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password', 'danger')
            return redirect(url_for('login'))
        
        login_user(user, remember=form.remember_me.data)
        next_page = request.args.get('next')
        
        if not next_page or urlparse(next_page).netloc != '':
            next_page = url_for('dashboard')
            
        return redirect(next_page)
    
    return render_template('login.html', title='Sign In', form=form)

@app.route('/logout')
def logout():
    logout_user()
    flash('You have been logged out successfully', 'success')
    return redirect(url_for('login'))

# Dashboard route
@app.route('/dashboard')
@login_required
def dashboard():
    # Get some basic stats for the dashboard
    total_dishes = Dish.query.count()
    total_orders = Order.query.count()
    total_staff = Staff.query.count()
    
    # Get today's orders
    today = datetime.now().date()
    today_orders = Order.query.filter(
        func.date(Order.created_at) == today
    ).count()
    
    # Get today's revenue
    today_revenue = db.session.query(func.sum(Order.total_amount)).filter(
        func.date(Order.created_at) == today,
        Order.status != 'cancelled'
    ).scalar() or 0
    
    # Get recent orders
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
    
    # Get top selling dishes
    top_dishes = db.session.query(
        Dish.id, Dish.name, func.sum(OrderItem.quantity).label('total_sold')
    ).join(OrderItem).group_by(Dish.id).order_by(desc('total_sold')).limit(5).all()
    
    return render_template(
        'dashboard.html', 
        title='Dashboard',
        total_dishes=total_dishes,
        total_orders=total_orders,
        total_staff=total_staff,
        today_orders=today_orders,
        today_revenue=today_revenue,
        recent_orders=recent_orders,
        top_dishes=top_dishes
    )

# Menu management routes
@app.route('/menu')
@login_required
def menu():
    categories = Category.query.all()
    dishes = Dish.query.all()
    return render_template('menu.html', title='Menu Management', categories=categories, dishes=dishes)

@app.route('/menu/category/add', methods=['GET', 'POST'])
@login_required
def add_category():
    form = CategoryForm()
    if form.validate_on_submit():
        category = Category(
            name=form.name.data,
            description=form.description.data
        )
        db.session.add(category)
        db.session.commit()
        flash('Category added successfully!', 'success')
        return redirect(url_for('menu'))
    return render_template('dish_form.html', title='Add Category', form=form, is_category=True)

@app.route('/menu/category/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_category(id):
    category = Category.query.get_or_404(id)
    form = CategoryForm(obj=category)
    if form.validate_on_submit():
        category.name = form.name.data
        category.description = form.description.data
        db.session.commit()
        flash('Category updated successfully!', 'success')
        return redirect(url_for('menu'))
    return render_template('dish_form.html', title='Edit Category', form=form, is_category=True)

@app.route('/menu/dish/add', methods=['GET', 'POST'])
@login_required
def add_dish():
    form = DishForm()
    if form.validate_on_submit():
        dish = Dish(
            name=form.name.data,
            description=form.description.data,
            price=form.price.data,
            cost=form.cost.data,
            image_url=form.image_url.data,
            is_available=form.is_available.data,
            category_id=form.category_id.data
        )
        db.session.add(dish)
        db.session.commit()
        flash('Dish added successfully!', 'success')
        return redirect(url_for('menu'))
    return render_template('dish_form.html', title='Add Dish', form=form)

@app.route('/menu/dish/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_dish(id):
    dish = Dish.query.get_or_404(id)
    form = DishForm(obj=dish)
    if form.validate_on_submit():
        dish.name = form.name.data
        dish.description = form.description.data
        dish.price = form.price.data
        dish.cost = form.cost.data
        dish.image_url = form.image_url.data
        dish.is_available = form.is_available.data
        dish.category_id = form.category_id.data
        db.session.commit()
        flash('Dish updated successfully!', 'success')
        return redirect(url_for('menu'))
    return render_template('dish_form.html', title='Edit Dish', form=form)

@app.route('/menu/dish/<int:id>/delete', methods=['POST'])
@login_required
def delete_dish(id):
    dish = Dish.query.get_or_404(id)
    db.session.delete(dish)
    db.session.commit()
    flash('Dish deleted successfully!', 'success')
    return redirect(url_for('menu'))

# Order management routes
@app.route('/orders')
@login_required
def orders():
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('orders.html', title='Order Management', orders=orders)

@app.route('/orders/add', methods=['GET', 'POST'])
@login_required
def add_order():
    form = OrderForm()
    item_form = OrderItemForm()
    
    if request.method == 'POST' and form.validate_on_submit():
        order = Order(
            table_number=form.table_number.data,
            customer_name=form.customer_name.data,
            status=form.status.data,
            payment_method=form.payment_method.data,
            created_by=current_user.id
        )
        db.session.add(order)
        db.session.commit()
        flash('Order created! Now add items to the order.', 'success')
        return redirect(url_for('edit_order', id=order.id))
    
    return render_template('orders.html', title='Add New Order', form=form, item_form=item_form, is_new=True)

@app.route('/orders/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_order(id):
    order = Order.query.get_or_404(id)
    form = OrderForm(obj=order)
    item_form = OrderItemForm()
    
    if request.method == 'POST' and form.validate_on_submit():
        order.table_number = form.table_number.data
        order.customer_name = form.customer_name.data
        order.status = form.status.data
        order.payment_method = form.payment_method.data
        db.session.commit()
        flash('Order updated successfully!', 'success')
        return redirect(url_for('orders'))
    
    return render_template('orders.html', title='Edit Order', form=form, item_form=item_form, order=order, is_edit=True)

@app.route('/orders/<int:id>/add_item', methods=['POST'])
@login_required
def add_order_item(id):
    order = Order.query.get_or_404(id)
    form = OrderItemForm()
    
    if form.validate_on_submit():
        dish = Dish.query.get(form.dish_id.data)
        item = OrderItem(
            order_id=order.id,
            dish_id=form.dish_id.data,
            quantity=form.quantity.data,
            unit_price=dish.price,
            subtotal=dish.price * form.quantity.data,
            notes=form.notes.data
        )
        db.session.add(item)
        order.update_total()
        db.session.commit()
        flash('Item added to order successfully!', 'success')
    
    return redirect(url_for('edit_order', id=id))

@app.route('/orders/<int:order_id>/remove_item/<int:item_id>', methods=['POST'])
@login_required
def remove_order_item(order_id, item_id):
    order = Order.query.get_or_404(order_id)
    item = OrderItem.query.get_or_404(item_id)
    
    if item.order_id != order.id:
        abort(400)
    
    db.session.delete(item)
    order.update_total()
    db.session.commit()
    flash('Item removed from order successfully!', 'success')
    
    return redirect(url_for('edit_order', id=order_id))

@app.route('/orders/<int:id>/delete', methods=['POST'])
@login_required
def delete_order(id):
    order = Order.query.get_or_404(id)
    db.session.delete(order)
    db.session.commit()
    flash('Order deleted successfully!', 'success')
    return redirect(url_for('orders'))

@app.route('/orders/<int:id>/change_status/<status>', methods=['POST'])
@login_required
def change_order_status(id, status):
    order = Order.query.get_or_404(id)
    if status not in ['pending', 'preparing', 'completed', 'cancelled']:
        abort(400)
    
    order.status = status
    db.session.commit()
    flash(f'Order status changed to {status}!', 'success')
    return redirect(url_for('orders'))

# Staff management routes
@app.route('/staff')
@login_required
def staff():
    staff_members = Staff.query.all()
    return render_template('staff.html', title='Staff Management', staff_members=staff_members)

@app.route('/staff/add', methods=['GET', 'POST'])
@login_required
def add_staff():
    form = StaffForm()
    if form.validate_on_submit():
        staff = Staff(
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            position=form.position.data,
            contact_number=form.contact_number.data,
            email=form.email.data,
            hire_date=form.hire_date.data,
            salary=form.salary.data,
            address=form.address.data
        )
        db.session.add(staff)
        db.session.commit()
        flash('Staff member added successfully!', 'success')
        return redirect(url_for('staff'))
    return render_template('staff_form.html', title='Add Staff', form=form)

@app.route('/staff/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_staff(id):
    staff_member = Staff.query.get_or_404(id)
    form = StaffForm(obj=staff_member)
    if form.validate_on_submit():
        staff_member.first_name = form.first_name.data
        staff_member.last_name = form.last_name.data
        staff_member.position = form.position.data
        staff_member.contact_number = form.contact_number.data
        staff_member.email = form.email.data
        staff_member.hire_date = form.hire_date.data
        staff_member.salary = form.salary.data
        staff_member.address = form.address.data
        db.session.commit()
        flash('Staff information updated successfully!', 'success')
        return redirect(url_for('staff'))
    return render_template('staff_form.html', title='Edit Staff', form=form)

@app.route('/staff/<int:id>/delete', methods=['POST'])
@login_required
def delete_staff(id):
    staff_member = Staff.query.get_or_404(id)
    db.session.delete(staff_member)
    db.session.commit()
    flash('Staff member deleted successfully!', 'success')
    return redirect(url_for('staff'))

# Reports routes
@app.route('/reports')
@login_required
def reports():
    form = DateRangeForm()
    # Default to showing the last 7 days
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=7)
    form.start_date.data = start_date
    form.end_date.data = end_date
    
    return render_template('reports.html', title='Reports', form=form)

@app.route('/api/reports/sales', methods=['POST'])
@login_required
def sales_report():
    data = request.json
    start_date = datetime.strptime(data['start_date'], '%Y-%m-%d').date()
    end_date = datetime.strptime(data['end_date'], '%Y-%m-%d').date()
    
    # Get daily sales for the period
    daily_sales = db.session.query(
        func.date(Order.created_at).label('date'),
        func.sum(Order.total_amount).label('sales')
    ).filter(
        func.date(Order.created_at) >= start_date,
        func.date(Order.created_at) <= end_date,
        Order.status != 'cancelled'
    ).group_by(func.date(Order.created_at)).all()
    
    # Get total sales by category
    category_sales = db.session.query(
        Category.name,
        func.sum(OrderItem.subtotal).label('sales')
    ).join(Dish, Dish.id == OrderItem.dish_id)\
     .join(Category, Category.id == Dish.category_id)\
     .join(Order, Order.id == OrderItem.order_id)\
     .filter(
        func.date(Order.created_at) >= start_date,
        func.date(Order.created_at) <= end_date,
        Order.status != 'cancelled'
     ).group_by(Category.name).all()
    
    # Get top selling dishes
    top_dishes = db.session.query(
        Dish.name,
        func.sum(OrderItem.quantity).label('quantity'),
        func.sum(OrderItem.subtotal).label('sales')
    ).join(Order, Order.id == OrderItem.order_id)\
     .filter(
        func.date(Order.created_at) >= start_date,
        func.date(Order.created_at) <= end_date,
        Order.status != 'cancelled'
     ).group_by(Dish.name).order_by(desc('quantity')).limit(5).all()
    
    # Format the data for charts
    dates = [str(row.date) for row in daily_sales]
    sales = [float(row.sales) for row in daily_sales]
    
    category_names = [row.name for row in category_sales]
    category_values = [float(row.sales) for row in category_sales]
    
    dish_names = [row.name for row in top_dishes]
    dish_quantities = [int(row.quantity) for row in top_dishes]
    dish_sales = [float(row.sales) for row in top_dishes]
    
    return jsonify({
        'daily': {
            'labels': dates,
            'data': sales
        },
        'categories': {
            'labels': category_names,
            'data': category_values
        },
        'top_dishes': {
            'labels': dish_names,
            'quantities': dish_quantities,
            'sales': dish_sales
        }
    })

@app.route('/api/reports/inventory', methods=['POST'])
@login_required
def inventory_report():
    # For a real implementation, this would track inventory changes
    # For now, just return some mock data based on the current inventory
    inventories = Inventory.query.all()
    
    names = [item.name for item in inventories]
    quantities = [item.quantity for item in inventories]
    costs = [item.quantity * item.unit_cost for item in inventories]
    
    # Items below reorder level
    low_stock = [item for item in inventories if item.quantity <= item.reorder_level]
    low_stock_names = [item.name for item in low_stock]
    low_stock_quantities = [item.quantity for item in low_stock]
    low_stock_reorder = [item.reorder_level for item in low_stock]
    
    return jsonify({
        'inventory': {
            'labels': names,
            'quantities': quantities,
            'costs': costs
        },
        'low_stock': {
            'labels': low_stock_names,
            'quantities': low_stock_quantities,
            'reorder_levels': low_stock_reorder
        }
    })
