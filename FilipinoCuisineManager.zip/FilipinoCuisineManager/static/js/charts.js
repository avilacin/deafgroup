/**
 * Charts.js - Filipino Restaurant Management System
 * Handles chart generation for reports
 */

document.addEventListener('DOMContentLoaded', function() {
    // Chart color scheme - compatible with dark theme
    const chartColors = {
        primary: '#0d6efd',
        success: '#198754',
        info: '#0dcaf0',
        warning: '#ffc107',
        danger: '#dc3545',
        light: '#f8f9fa',
        dark: '#212529',
        muted: '#6c757d',
        primaryTransparent: 'rgba(13, 110, 253, 0.2)',
        successTransparent: 'rgba(25, 135, 84, 0.2)',
        infoTransparent: 'rgba(13, 202, 240, 0.2)',
        warningTransparent: 'rgba(255, 193, 7, 0.2)',
        dangerTransparent: 'rgba(220, 53, 69, 0.2)',
    };

    // Chart defaults
    Chart.defaults.color = '#ced4da';
    Chart.defaults.borderColor = 'rgba(255, 255, 255, 0.1)';
    Chart.defaults.font.family = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

    // Define charts
    let dailySalesChart = null;
    let categorySalesChart = null;
    let topDishesChart = null;
    let inventoryLevelsChart = null;
    let inventoryValueChart = null;
    let lowStockChart = null;

    // Generate report button click handler
    const generateReportBtn = document.getElementById('generateReportBtn');
    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', generateReport);
    }

    /**
     * Generate report based on selected criteria
     */
    function generateReport() {
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        const reportType = document.getElementById('report_type').value;

        // Validate dates
        if (!startDate || !endDate) {
            alert('Please select start and end dates');
            return;
        }

        // Check if end date is after start date
        if (new Date(endDate) < new Date(startDate)) {
            alert('End date must be after start date');
            return;
        }

        // Show loading indicator
        document.getElementById('loadingIndicator').classList.remove('d-none');
        document.getElementById('salesReportSection').classList.add('d-none');
        document.getElementById('inventoryReportSection').classList.add('d-none');
        document.getElementById('noDataMessage').classList.add('d-none');

        // Fetch report data based on type
        if (reportType === 'sales') {
            fetchSalesReport(startDate, endDate);
        } else {
            fetchInventoryReport();
        }
    }

    /**
     * Fetch sales report data from server
     */
    function fetchSalesReport(startDate, endDate) {
        fetch('/api/reports/sales', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                start_date: startDate,
                end_date: endDate
            })
        })
        .then(response => response.json())
        .then(data => {
            document.getElementById('loadingIndicator').classList.add('d-none');
            
            // Check if we have data
            if (data.daily.labels.length === 0) {
                document.getElementById('noDataMessage').classList.remove('d-none');
                return;
            }
            
            document.getElementById('salesReportSection').classList.remove('d-none');
            renderSalesReports(data);
        })
        .catch(error => {
            console.error('Error fetching sales report:', error);
            document.getElementById('loadingIndicator').classList.add('d-none');
            alert('Error generating report. Please try again.');
        });
    }

    /**
     * Fetch inventory report data from server
     */
    function fetchInventoryReport() {
        fetch('/api/reports/inventory', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({})
        })
        .then(response => response.json())
        .then(data => {
            document.getElementById('loadingIndicator').classList.add('d-none');
            
            // Check if we have data
            if (data.inventory.labels.length === 0) {
                document.getElementById('noDataMessage').classList.remove('d-none');
                return;
            }
            
            document.getElementById('inventoryReportSection').classList.remove('d-none');
            renderInventoryReports(data);
        })
        .catch(error => {
            console.error('Error fetching inventory report:', error);
            document.getElementById('loadingIndicator').classList.add('d-none');
            alert('Error generating report. Please try again.');
        });
    }

    /**
     * Render sales report charts
     */
    function renderSalesReports(data) {
        // Destroy existing charts
        if (dailySalesChart) dailySalesChart.destroy();
        if (categorySalesChart) categorySalesChart.destroy();
        if (topDishesChart) topDishesChart.destroy();

        // Daily Sales Line Chart
        const dailySalesCtx = document.getElementById('dailySalesChart').getContext('2d');
        dailySalesChart = new Chart(dailySalesCtx, {
            type: 'line',
            data: {
                labels: data.daily.labels,
                datasets: [{
                    label: 'Daily Sales (₱)',
                    data: data.daily.data,
                    borderColor: chartColors.primary,
                    backgroundColor: chartColors.primaryTransparent,
                    borderWidth: 2,
                    fill: true,
                    tension: 0.2,
                    pointBackgroundColor: chartColors.primary,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: function(context) {
                                return `Sales: ₱${context.raw.toFixed(2)}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value;
                            }
                        }
                    }
                }
            }
        });

        // Category Sales Doughnut Chart
        const categorySalesCtx = document.getElementById('categorySalesChart').getContext('2d');
        categorySalesChart = new Chart(categorySalesCtx, {
            type: 'doughnut',
            data: {
                labels: data.categories.labels,
                datasets: [{
                    data: data.categories.data,
                    backgroundColor: [
                        chartColors.primary,
                        chartColors.success,
                        chartColors.warning,
                        chartColors.danger,
                        chartColors.info
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const value = context.raw;
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${context.label}: ₱${value.toFixed(2)} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });

        // Top Dishes Bar Chart
        const topDishesCtx = document.getElementById('topDishesChart').getContext('2d');
        topDishesChart = new Chart(topDishesCtx, {
            type: 'bar',
            data: {
                labels: data.top_dishes.labels,
                datasets: [
                    {
                        label: 'Quantity Sold',
                        data: data.top_dishes.quantities,
                        backgroundColor: chartColors.primaryTransparent,
                        borderColor: chartColors.primary,
                        borderWidth: 1,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Sales Amount (₱)',
                        data: data.top_dishes.sales,
                        backgroundColor: chartColors.successTransparent,
                        borderColor: chartColors.success,
                        borderWidth: 1,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        title: {
                            display: true,
                            text: 'Quantity'
                        },
                        position: 'left',
                        beginAtZero: true
                    },
                    y1: {
                        title: {
                            display: true,
                            text: 'Sales (₱)'
                        },
                        position: 'right',
                        beginAtZero: true,
                        grid: {
                            drawOnChartArea: false
                        },
                        ticks: {
                            callback: function(value) {
                                return '₱' + value;
                            }
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 45,
                            minRotation: 45
                        }
                    }
                }
            }
        });
    }

    /**
     * Render inventory report charts
     */
    function renderInventoryReports(data) {
        // Destroy existing charts
        if (inventoryLevelsChart) inventoryLevelsChart.destroy();
        if (inventoryValueChart) inventoryValueChart.destroy();
        if (lowStockChart) lowStockChart.destroy();

        // Inventory Levels Bar Chart
        const inventoryLevelsCtx = document.getElementById('inventoryLevelsChart').getContext('2d');
        inventoryLevelsChart = new Chart(inventoryLevelsCtx, {
            type: 'bar',
            data: {
                labels: data.inventory.labels,
                datasets: [{
                    label: 'Current Quantity',
                    data: data.inventory.quantities,
                    backgroundColor: chartColors.infoTransparent,
                    borderColor: chartColors.info,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Quantity'
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 45,
                            minRotation: 45
                        }
                    }
                }
            }
        });

        // Inventory Value Pie Chart
        const inventoryValueCtx = document.getElementById('inventoryValueChart').getContext('2d');
        inventoryValueChart = new Chart(inventoryValueCtx, {
            type: 'pie',
            data: {
                labels: data.inventory.labels,
                datasets: [{
                    data: data.inventory.costs,
                    backgroundColor: [
                        chartColors.primary,
                        chartColors.success,
                        chartColors.warning,
                        chartColors.danger,
                        chartColors.info,
                        chartColors.muted
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                return `${context.label}: ₱${value.toFixed(2)}`;
                            }
                        }
                    }
                }
            }
        });

        // Low Stock Chart
        const lowStockCtx = document.getElementById('lowStockChart').getContext('2d');
        lowStockChart = new Chart(lowStockCtx, {
            type: 'bar',
            data: {
                labels: data.low_stock.labels,
                datasets: [
                    {
                        label: 'Current Quantity',
                        data: data.low_stock.quantities,
                        backgroundColor: chartColors.dangerTransparent,
                        borderColor: chartColors.danger,
                        borderWidth: 1
                    },
                    {
                        label: 'Reorder Level',
                        data: data.low_stock.reorder_levels,
                        backgroundColor: chartColors.warningTransparent,
                        borderColor: chartColors.warning,
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Quantity'
                        }
                    }
                }
            }
        });
    }
});
