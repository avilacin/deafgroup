/**
 * Script.js - Filipino Restaurant Management System
 * Common JavaScript functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Add animation to flash messages and auto-dismiss them
    const flashMessages = document.querySelectorAll('.alert');
    if (flashMessages.length > 0) {
        flashMessages.forEach(message => {
            // Fade out messages after 5 seconds
            setTimeout(() => {
                message.classList.add('fade');
                setTimeout(() => {
                    message.remove();
                }, 500);
            }, 5000);
        });
    }

    // Initialize all tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize all popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Handle sidebar toggle for mobile views
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('show');
        });
    }
    
    // Add active class to the current menu item based on URL
    const currentLocation = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href && currentLocation.startsWith(href)) {
            link.classList.add('active');
        }
    });

    // Auto-resize textareas as content grows
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(textarea => {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
    });

    // Confirm delete actions with custom confirmation
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });

    // Image preview for dish image URLs
    const imageUrlInput = document.getElementById('image_url');
    if (imageUrlInput) {
        const previewContainer = document.createElement('div');
        previewContainer.className = 'mt-2';
        previewContainer.id = 'imagePreview';
        imageUrlInput.parentNode.appendChild(previewContainer);

        imageUrlInput.addEventListener('blur', function() {
            const url = this.value.trim();
            if (url) {
                previewContainer.innerHTML = `
                    <p class="form-text">Image Preview:</p>
                    <img src="${url}" class="img-thumbnail" style="max-width: 200px; max-height: 150px;" alt="Image preview" onerror="this.onerror=null; this.src=''; this.alt='Invalid image URL'; this.className='d-none';">
                `;
            } else {
                previewContainer.innerHTML = '';
            }
        });
    }

    // Order item quantity change handlers
    const quantityInputs = document.querySelectorAll('.item-quantity');
    quantityInputs.forEach(input => {
        input.addEventListener('change', updateOrderSubtotal);
    });

    // Order status badge colors
    updateOrderStatusColors();

    // Real-time date validation for reports
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    if (startDateInput && endDateInput) {
        endDateInput.addEventListener('change', validateDateRange);
    }
});

/**
 * Update order item subtotals when quantity changes
 */
function updateOrderSubtotal(e) {
    const quantity = parseInt(e.target.value);
    const row = e.target.closest('tr');
    const unitPrice = parseFloat(row.querySelector('.unit-price').dataset.price);
    const subtotalElement = row.querySelector('.subtotal');
    
    if (quantity > 0 && !isNaN(unitPrice)) {
        const subtotal = quantity * unitPrice;
        subtotalElement.textContent = `₱${subtotal.toFixed(2)}`;
        subtotalElement.dataset.subtotal = subtotal;
    }
    
    // Recalculate order total
    updateOrderTotal();
}

/**
 * Update order total amount
 */
function updateOrderTotal() {
    const subtotals = document.querySelectorAll('.subtotal');
    let total = 0;
    
    subtotals.forEach(element => {
        total += parseFloat(element.dataset.subtotal || 0);
    });
    
    const totalElement = document.getElementById('orderTotal');
    if (totalElement) {
        totalElement.textContent = `₱${total.toFixed(2)}`;
    }
}

/**
 * Apply appropriate colors to order status badges
 */
function updateOrderStatusColors() {
    const statusBadges = document.querySelectorAll('.status-badge');
    statusBadges.forEach(badge => {
        const status = badge.dataset.status;
        let className = '';
        
        switch (status) {
            case 'pending':
                className = 'bg-warning';
                break;
            case 'preparing':
                className = 'bg-info';
                break;
            case 'completed':
                className = 'bg-success';
                break;
            case 'cancelled':
                className = 'bg-danger';
                break;
            default:
                className = 'bg-secondary';
        }
        
        badge.className = `badge ${className} status-badge`;
    });
}

/**
 * Validate date range for reports
 */
function validateDateRange() {
    const startDate = new Date(document.getElementById('start_date').value);
    const endDate = new Date(document.getElementById('end_date').value);
    const errorMsg = document.getElementById('dateRangeError');
    
    if (endDate < startDate) {
        if (!errorMsg) {
            const error = document.createElement('div');
            error.id = 'dateRangeError';
            error.className = 'text-danger mt-2';
            error.textContent = 'End date cannot be earlier than start date';
            document.getElementById('end_date').parentNode.appendChild(error);
        }
        document.getElementById('generateReportBtn').disabled = true;
    } else {
        if (errorMsg) {
            errorMsg.remove();
        }
        document.getElementById('generateReportBtn').disabled = false;
    }
}
