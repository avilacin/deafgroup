from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, FloatField, IntegerField, SelectField, TextAreaField, DateField, HiddenField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError, Optional, NumberRange
from models import User, Category, Dish

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')

class CategoryForm(FlaskForm):
    name = StringField('Category Name', validators=[DataRequired(), Length(min=2, max=50)])
    description = TextAreaField('Description', validators=[Optional(), Length(max=200)])
    submit = SubmitField('Save Category')

class DishForm(FlaskForm):
    name = StringField('Dish Name', validators=[DataRequired(), Length(min=2, max=100)])
    description = TextAreaField('Description', validators=[Optional()])
    price = FloatField('Price', validators=[DataRequired(), NumberRange(min=0)])
    cost = FloatField('Cost', validators=[DataRequired(), NumberRange(min=0)])
    image_url = StringField('Image URL', validators=[Optional()])
    is_available = BooleanField('Available')
    category_id = SelectField('Category', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Save Dish')
    
    def __init__(self, *args, **kwargs):
        super(DishForm, self).__init__(*args, **kwargs)
        self.category_id.choices = [(c.id, c.name) for c in Category.query.all()]

class StaffForm(FlaskForm):
    first_name = StringField('First Name', validators=[DataRequired(), Length(min=2, max=50)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(min=2, max=50)])
    position = StringField('Position', validators=[DataRequired(), Length(min=2, max=50)])
    contact_number = StringField('Contact Number', validators=[DataRequired(), Length(min=6, max=20)])
    email = StringField('Email', validators=[Optional(), Email()])
    hire_date = DateField('Hire Date', validators=[DataRequired()], format='%Y-%m-%d')
    salary = FloatField('Salary', validators=[DataRequired(), NumberRange(min=0)])
    address = TextAreaField('Address', validators=[Optional(), Length(max=200)])
    submit = SubmitField('Save Staff')

class OrderForm(FlaskForm):
    table_number = IntegerField('Table Number', validators=[Optional()])
    customer_name = StringField('Customer Name', validators=[Optional(), Length(max=100)])
    status = SelectField('Status', choices=[('pending', 'Pending'), ('preparing', 'Preparing'), ('completed', 'Completed'), ('cancelled', 'Cancelled')])
    payment_method = SelectField('Payment Method', choices=[('', 'Select Payment Method'), ('cash', 'Cash'), ('card', 'Card'), ('mobile', 'Mobile Payment')])
    submit = SubmitField('Save Order')

class OrderItemForm(FlaskForm):
    dish_id = SelectField('Dish', coerce=int, validators=[DataRequired()])
    quantity = IntegerField('Quantity', validators=[DataRequired(), NumberRange(min=1)])
    notes = TextAreaField('Notes', validators=[Optional()])
    submit = SubmitField('Add to Order')
    
    def __init__(self, *args, **kwargs):
        super(OrderItemForm, self).__init__(*args, **kwargs)
        self.dish_id.choices = [(d.id, f"{d.name} - ₱{d.price:.2f}") for d in Dish.query.filter_by(is_available=True).all()]

class DateRangeForm(FlaskForm):
    start_date = DateField('Start Date', validators=[DataRequired()], format='%Y-%m-%d')
    end_date = DateField('End Date', validators=[DataRequired()], format='%Y-%m-%d')
    report_type = SelectField('Report Type', choices=[('sales', 'Sales Report'), ('inventory', 'Inventory Report')])
    submit = SubmitField('Generate Report')
